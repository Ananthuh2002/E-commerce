import React from 'react'

const Productdisplay = (props) => {
    const {product} = props
  return (
    <div className='product'>
        <div className='product-image'>
        <img src={product.image} alt={product.name} />
       < img src={product.image} alt={product.name} />
       < img src={product.image} alt={product.name} />
       < img src={product.image} alt={product.name} />
        </div>
        <div className='product-details'>
        <p className='caption'>{product.name}</p>
    <div className='prices'>
    <p>${product.new_price}</p>
    <p className='old-price'>${product.old_price}</p>
    </div>
        </div>
    </div>
  )
}

export default Productdisplay