import React from 'react'
import './Popular.css'
import data_product from '../Assests/data'

export const Popular = () => {
  return (
    <div className='popular'>
         <h2>POPULAR IN WOMEN</h2>
         <div className='popular-item'>
         {data_product.map((item) => (
  <div className='item-list'
   key={item.id}>
    <img src={item.image} alt={item.name} />
    <p className='caption'>{item.name}</p>
    <div className='prices'>
    <p>${item.new_price}</p>
    <p className='old-price'>${item.old_price}</p>
    </div>
  </div>
))}     </div>
    </div>
  )
} 

