import React from 'react'

function Item(props) {
  return (
    <div className='items'>

    </div>
  )
}

export default Item

//https://youtu.be/jbfuzcrfjqQ?si=74z5I1Fdcb7PWpWl