import img1 from './img1.jpg'
import img2 from './img2.jpg'
import img3 from './img3.jpg'
import img4 from './img4.jpg'


let Images =[
    {
        id:1,
        name:img1
    },
    {
        id:2,
        name:img2
    },
    {
        id:3,
        name:img3
    },
    {
        id:4,
        name:img4
    }
];
export default Images;